const getters = {
  page_buttons: state => state.pageButton.page_buttons,
  token: state => state.user.token,
}
export default getters
