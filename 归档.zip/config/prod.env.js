module.exports = {
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
  BASE_API: '"https://easy-mock.com/mock/5b023d09b748c95f2a605326/example/"'
};

